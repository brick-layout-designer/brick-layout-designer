Left switch cut 150: layout parts
=================================

Made with Brick Track Designer. The folder "Left switch cut 150" is a parts library for
the Collaborative Brick Layout Designer (and BlueBrick): one part for each
printed track part of the design, as cut for the print bed (the points,
throws and levers drawn on the part they go in), each with its connection
points where the track leaves it, so they snap together and onto other track.
The set "Left_switch_cut_150.whole" puts all of them down as designed.

Collaborative Brick Layout Designer (desktop 1.4.0 or later)
  1. Tools > Parts > Add Parts from a Zip..., and choose this zip: it's
     unpacked into the imports folder and the parts reloaded.
     (Or unzip it somewhere to keep it, then Tools > Parts > Parts
     Folders..., Add..., choose the "Left switch cut 150" folder, OK.)
  2. The set is in the Parts panel under the category "Left switch cut 150": drag
     "Left switch cut 150 (all ... parts, as designed)" onto the map. The pieces are
     hidden in the parts library (they only make sense in their set): place
     the whole set, then Ungroup it to move them one at a time.
  After exporting again (the design changed), add the new zip the same way
  (or unzip over the old folder and use Tools > Parts > Reload Parts): maps
  using the parts show the new ones.
  Sharing through a server: "Upload to server..." (the server window's Parts
  tab) sends these parts from whichever parts folder they're in, and the set
  too where the server takes sets; the web version places the set as one
  group.
  Checking the joins: bld-render --check-connections <this zip> lists the
  parts' connection points that pair up, the open ends, and any that nearly
  meet but don't.

BlueBrick
  Copy the "Left switch cut 150" folder into BlueBrick's "parts" folder (beside
  "Track", "Custom" and so on) and restart BlueBrick (or reload the part
  library).

The parts' names are "Left_switch_cut_150.<part>": save a different design under a
name of its own before exporting it, or its parts take the place of these.
