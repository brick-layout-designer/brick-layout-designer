Left switch cut 150: layout parts
=================================

Made with Brick Track Designer. The folder "Left switch cut 150" is a parts library for
the collaborative layout designer (and BlueBrick): one part for each printed
track part of the design, as cut for the print bed (the points, throws and
levers drawn on the part they go in), each with its connection points where
the track leaves it, so they snap together and onto other track. The set
"Left_switch_cut_150.whole" puts all of them down as designed.

Collaborative layout designer
  1. Unzip this somewhere to keep it (the folder must stay where it is).
  2. Tools > Parts > Parts Folders..., Add..., choose the "Left switch cut 150" folder
     (or the folder it is in), OK.
  3. The parts are in the Parts panel under the category "Left switch cut 150".
     Drag "Left switch cut 150 (all ... parts, as designed)" onto the map for the whole
     design, or the parts one at a time.
  After exporting again (the design changed), unzip over the old folder and
  use Tools > Parts > Reload Parts: maps using the parts show the new ones.
  Sharing through a server: "Upload to server..." (the server window's Parts
  tab) sends only the parts in the layout designer's own imports folder, not
  other parts folders, and not sets: to share the parts, unzip the folder
  into that imports folder instead.

BlueBrick
  Copy the "Left switch cut 150" folder into BlueBrick's "parts" folder (beside
  "Track", "Custom" and so on) and restart BlueBrick (or reload the part
  library).

The parts' names are "Left_switch_cut_150.<part>": save a different design under a
name of its own before exporting it, or its parts take the place of these.
